import express from "express";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json({ limit: "12mb" }));

app.get("/health", (_req, res) => res.json({ ok: true, service: "AI BELAJAR" }));

app.post("/api/ask", async (req, res) => {
  try {
    const { question, imageDataUrl, mode = "explain", studentAnswer = "", answerKey = "" } = req.body ?? {};
    if (!question?.trim() && !imageDataUrl) {
      return res.status(400).json({ error: "Tulis soal atau pilih foto soal terlebih dahulu." });
    }
    if (imageDataUrl && !/^data:image\/(png|jpeg|webp);base64,/.test(imageDataUrl)) {
      return res.status(400).json({ error: "Format foto harus PNG, JPG, atau WEBP." });
    }
    if (imageDataUrl && imageDataUrl.length > 9_000_000) {
      return res.status(413).json({ error: "Ukuran foto terlalu besar. Pilih foto yang lebih kecil." });
    }
    if (!process.env.OPENAI_API_KEY) {
      return res.status(500).json({ error: "API key belum dipasang di backend." });
    }

    let instruction;
    if (mode === "grade") {
      instruction = `Kamu adalah tutor yang menilai latihan belajar. Nilai jawaban siswa secara adil.
Soal: ${question || "(Baca soal pada gambar terlampir)"}
Jawaban siswa: ${studentAnswer || "(belum diisi)"}
Kunci/patokan jawaban (jika tersedia): ${answerKey || "(tidak diberikan)"}
Berikan: (1) skor 0-100 beserta alasan, (2) bagian yang benar, (3) bagian yang perlu diperbaiki, (4) jawaban/pembahasan yang benar. Jika informasi tidak cukup, jelaskan keterbatasannya dan jangan mengarang.`;
    } else {
      instruction = `Kamu adalah AI tutor untuk membantu belajar. Jawab dalam Bahasa Indonesia yang jelas.
Baca soal dari teks dan/atau gambar. Berikan:
1. Jawaban singkat.
2. Penjelasan langkah demi langkah.
3. Konsep atau rumus yang digunakan.
4. Pemeriksaan hasil dan catatan jika gambar/soal kurang jelas.
Jangan mengarang bagian soal yang tidak terbaca.`;
    }

    const content = [{ type: "input_text", text: `${instruction}\n\nTeks dari pengguna: ${question || "(tidak ada teks tambahan)"}` }];
    if (imageDataUrl) content.push({ type: "input_image", image_url: imageDataUrl });

    const response = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.OPENAI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
        input: [{ role: "user", content }]
      })
    });

    const data = await response.json();
    if (!response.ok) {
      const message = data?.error?.message || "Layanan AI gagal memproses permintaan.";
      return res.status(response.status).json({ error: message });
    }
    const answer = data.output_text ||
      (data.output || []).flatMap(x => x.content || []).filter(x => x.type === "output_text").map(x => x.text).join("\n");
    return res.json({ answer: answer || "AI tidak mengembalikan teks. Coba ulangi dengan soal yang lebih jelas." });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "Terjadi kesalahan pada server. Coba lagi nanti." });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`AI BELAJAR backend berjalan pada port ${port}`));
