package com.aibelajar.app

import android.net.Uri
import android.os.Bundle
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Navy = Color(0xFF14213D)
private val Blue = Color(0xFF356AE6)
private val Pale = Color(0xFFF3F6FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AIBelajarApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AIBelajarApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var question by remember { mutableStateOf("") }
    var studentAnswer by remember { mutableStateOf("") }
    var answerKey by remember { mutableStateOf("") }
    var selectedImage by remember { mutableStateOf<Uri?>(null) }
    var answer by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var menuExpanded by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("explain") }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        selectedImage = it
    }

    fun submit(selectedMode: String) {
        if (question.isBlank() && selectedImage == null) {
            error = "Tulis soal atau pilih foto terlebih dahulu."
            return
        }
        if (selectedMode == "grade" && studentAnswer.isBlank()) {
            error = "Isi jawabanmu terlebih dahulu untuk dinilai."
            return
        }
        loading = true
        error = ""
        answer = ""
        scope.launch {
            try {
                val imageData = selectedImage?.let { uriToDataUrl(context, it) }
                val result = withContext(Dispatchers.IO) {
                    askBackend(question, imageData, selectedMode, studentAnswer, answerKey)
                }
                answer = result
            } catch (e: Exception) {
                error = e.message ?: "Tidak dapat terhubung ke server."
            } finally {
                loading = false
            }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            secondary = Navy,
            background = Pale,
            surface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Pale,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("AI BELAJAR", fontWeight = FontWeight.ExtraBold, color = Navy)
                            Text("Teman belajar pintar", fontSize = 12.sp, color = Color.Gray)
                        }
                    },
                    actions = {
                        IconButton(onClick = { question = ""; studentAnswer = ""; answerKey = ""; selectedImage = null; answer = ""; error = "" }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reset")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
                )
            },
            floatingActionButton = {
                Column(horizontalAlignment = Alignment.End) {
                    if (menuExpanded) {
                        SmallFloatingActionButton(
                            onClick = { mode = "explain"; menuExpanded = false },
                            containerColor = Color.White
                        ) { Icon(Icons.Default.AutoAwesome, contentDescription = "Tanya AI") }
                        Spacer(Modifier.height(10.dp))
                        SmallFloatingActionButton(
                            onClick = { imagePicker.launch("image/*"); menuExpanded = false },
                            containerColor = Color.White
                        ) { Icon(Icons.Default.Image, contentDescription = "Foto soal") }
                        Spacer(Modifier.height(10.dp))
                        SmallFloatingActionButton(
                            onClick = { mode = "grade"; menuExpanded = false },
                            containerColor = Color.White
                        ) { Icon(Icons.Default.Grade, contentDescription = "Penilaian") }
                        Spacer(Modifier.height(10.dp))
                    }
                    FloatingActionButton(
                        onClick = { menuExpanded = !menuExpanded },
                        containerColor = Blue,
                        contentColor = Color.White
                    ) {
                        Icon(if (menuExpanded) Icons.Default.Close else Icons.Default.Menu, contentDescription = "Menu fitur")
                    }
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Navy),
                    shape = RoundedCornerShape(22.dp)
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Belajar jadi lebih mudah ✨", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                        Text("Tanyakan soal, unggah foto, dan pahami cara menyelesaikannya bersama AI.", color = Color(0xFFDCE5F7))
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = mode == "explain",
                        onClick = { mode = "explain" },
                        label = { Text("Tanya & jelaskan") },
                        leadingIcon = { Icon(Icons.Default.AutoAwesome, null) }
                    )
                    FilterChip(
                        selected = mode == "grade",
                        onClick = { mode = "grade" },
                        label = { Text("Nilai jawaban") },
                        leadingIcon = { Icon(Icons.Default.Grade, null) }
                    )
                }

                Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (mode == "grade") "Latihan dan penilaian" else "Apa yang ingin kamu pelajari?", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Navy)
                        OutlinedTextField(
                            value = question,
                            onValueChange = { question = it },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 3,
                            label = { Text("Tulis soal atau pertanyaan") },
                            placeholder = { Text("Contoh: Jelaskan proses fotosintesis...") }
                        )
                        OutlinedButton(
                            onClick = { imagePicker.launch("image/*") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (selectedImage == null) "Pilih foto soal" else "Ganti foto soal")
                        }
                        selectedImage?.let {
                            AsyncImage(model = it, contentDescription = "Foto soal terpilih", modifier = Modifier.fillMaxWidth().heightIn(max = 220.dp).clip(RoundedCornerShape(12.dp)))
                            TextButton(onClick = { selectedImage = null }) { Text("Hapus foto") }
                        }

                        if (mode == "grade") {
                            OutlinedTextField(
                                value = studentAnswer,
                                onValueChange = { studentAnswer = it },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2,
                                label = { Text("Jawabanmu") }
                            )
                            OutlinedTextField(
                                value = answerKey,
                                onValueChange = { answerKey = it },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2,
                                label = { Text("Kunci jawaban (opsional)") }
                            )
                        }

                        Button(
                            onClick = { submit(mode) },
                            enabled = !loading,
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            if (loading) CircularProgressIndicator(Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                            else {
                                Icon(if (mode == "grade") Icons.Default.FactCheck else Icons.Default.Send, null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (mode == "grade") "Nilai jawaban" else "Tanya AI")
                            }
                        }
                    }
                }

                if (error.isNotBlank()) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEEEE))) {
                        Text(error, Modifier.padding(14.dp), color = Color(0xFFB3261E))
                    }
                }
                if (answer.isNotBlank()) {
                    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Blue)
                                Spacer(Modifier.width(8.dp))
                                Text("Hasil dari AI", fontWeight = FontWeight.Bold, color = Navy, fontSize = 18.sp)
                            }
                            Text(answer, lineHeight = 23.sp)
                        }
                    }
                }
                Text("Periksa kembali jawaban AI. Gunakan sebagai pendamping belajar.", color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.height(76.dp))
            }
        }
    }
}

private fun uriToDataUrl(context: android.content.Context, uri: Uri): String {
    val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        ?: error("Foto tidak dapat dibaca.")
    require(bytes.size <= 6 * 1024 * 1024) { "Ukuran foto maksimal 6 MB." }
    val mime = context.contentResolver.getType(uri) ?: "image/jpeg"
    val safeMime = if (mime in listOf("image/png", "image/jpeg", "image/webp")) mime else "image/jpeg"
    return "data:$safeMime;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
}

private fun askBackend(
    question: String,
    imageDataUrl: String?,
    mode: String,
    studentAnswer: String,
    answerKey: String
): String {
    val base = BuildConfig.AI_API_URL.trimEnd('/')
    require(base.startsWith("https://")) { "Atur AI_API_URL dengan alamat backend HTTPS terlebih dahulu." }
    val conn = (URL("$base/api/ask").openConnection() as HttpURLConnection).apply {
        requestMethod = "POST"
        connectTimeout = 20000
        readTimeout = 90000
        doOutput = true
        setRequestProperty("Content-Type", "application/json; charset=utf-8")
    }
    val body = JSONObject().apply {
        put("question", question)
        put("mode", mode)
        put("studentAnswer", studentAnswer)
        put("answerKey", answerKey)
        if (imageDataUrl != null) put("imageDataUrl", imageDataUrl)
    }.toString()
    conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
    val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
    val response = stream.bufferedReader().use { it.readText() }
    conn.disconnect()
    val json = JSONObject(response)
    if (json.has("error")) error(json.getString("error"))
    return json.optString("answer", "Tidak ada jawaban yang diterima.")
}
