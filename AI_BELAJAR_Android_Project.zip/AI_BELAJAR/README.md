# AI BELAJAR — project Android + backend AI

Project ini berisi aplikasi Android native (Kotlin + Jetpack Compose) dan backend Node.js.
Fitur:
- Tanya AI untuk soal teks
- Pilih foto soal dari galeri
- Penjelasan langkah demi langkah
- Mode latihan/penilaian otomatis (jawaban siswa dibandingkan dengan pembahasan AI)
- Tombol menu mengambang untuk membuka fitur cepat

## Penting
Aplikasi Android **tidak menyimpan API key**. Kunci API disimpan di backend Node.js.
Jangan pernah menaruh API key di file Kotlin atau membagikannya ke orang lain.
Backend harus dipasang di hosting HTTPS agar aplikasi dapat digunakan dari luar jaringan rumah.

## 1. Menyiapkan backend AI
Butuh Node.js 20 atau lebih baru dan API key OpenAI.

Di folder `backend`, salin `.env.example` menjadi `.env`, lalu isi:
```
OPENAI_API_KEY=isi_api_key_anda
OPENAI_MODEL=gpt-4.1-mini
PORT=3000
```
Jalankan:
```
npm install
npm start
```
Tes melalui browser: `http://localhost:3000/health`
Harus muncul `{"ok":true}`.

Untuk penggunaan sungguhan, deploy folder backend ke layanan hosting Node.js yang mendukung environment variables dan HTTPS. Isi `OPENAI_API_KEY` dan `OPENAI_MODEL` di dashboard hosting, jangan unggah `.env`.

## 2. Menghubungkan aplikasi Android ke backend
Buka project folder `android` dengan Android Studio.
Edit `app/build.gradle.kts`, ubah:
```
buildConfigField("String", "AI_API_URL", "\"https://ALAMAT-BACKEND-ANDA\"")
```
menjadi URL HTTPS backend milikmu, tanpa garis miring di akhir.
Jangan gunakan `localhost` di HP karena localhost berarti HP itu sendiri, bukan komputer/server backend.

## 3. Menjalankan di HP Android
1. Install Android Studio di komputer, buka folder `android`.
2. Tunggu Gradle Sync selesai.
3. Sambungkan HP dengan USB debugging aktif, atau gunakan emulator.
4. Tekan tombol Run.
5. Untuk membuat APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug biasanya ada di `app/build/outputs/apk/debug/app-debug.apk`.

Jika hanya punya HP Android dan tidak punya komputer, kamu tetap bisa mengedit backend dari layanan cloud, tetapi proses build APK native lebih mudah dilakukan dengan Android Studio di komputer. File ZIP ini adalah source project, bukan APK siap-install.

## Cara memakai
- Ketik soal lalu tekan **Tanya AI**.
- Tekan **Foto soal** untuk memilih gambar dari galeri.
- Untuk penilaian, isi soal, jawaban siswa, dan (jika ada) kunci jawaban lalu tekan **Nilai jawaban**.
- Jawaban AI adalah alat bantu belajar; periksa kembali hasilnya dan jangan gunakan sebagai pengganti guru atau sumber resmi.

## Keamanan produksi yang disarankan
- Pasang autentikasi dan pembatasan penggunaan (rate limit) pada backend.
- Tambahkan batas ukuran foto dan pemantauan biaya API.
- Jangan menyimpan foto atau pertanyaan pengguna tanpa persetujuan.
- Jangan menaruh API key di aplikasi Android.
